#!/bin/sh
cd "$(dirname "$0")" && exec ./game1 "$@"