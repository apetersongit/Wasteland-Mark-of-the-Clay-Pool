Welcome to WASTELAND: Mark of the Clay Pool (Mac version)!

How to run the game:

1. Download WMCP.zip and extract it by double clicking or run:
unzip WMCP-Mac.zip

2. Move the files to Desktop (or location of your choice, the below instructions assume it is in your Desktop)

3. Since this game is not signed by an Apple developer, macOS blocks it after a browser download. Remove the block from Terminal with:
xattr -dr com.apple.quarantine Desktop/WMCP

4. Run the game in the terminal. In a terminal run:
cd Desktop
cd WMCP
Then:
./run.sh
and the game should open!