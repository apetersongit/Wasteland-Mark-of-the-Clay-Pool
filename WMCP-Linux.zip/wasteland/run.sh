#!/bin/sh
cd "$(dirname "$0")" || exit 1
LD_LIBRARY_PATH="$PWD/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH
exec ./game1 "$@"
