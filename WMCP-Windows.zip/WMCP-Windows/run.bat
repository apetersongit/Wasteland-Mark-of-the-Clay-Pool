@echo off
cd /d "%~dp0"
WMCP.exe %*